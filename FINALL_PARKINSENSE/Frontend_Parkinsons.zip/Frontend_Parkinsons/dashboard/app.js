/* ==========================================================================
   ASSISTIVE TECHNOLOGY PLATFORM DASHBOARD - LOGIC MODULE
   Self-contained JavaScript engine for Speech, Writing OCR, Motor Spiral Assessment,
   Progress Charts, Doctor Dashboard, Accessibility, and Mock Data Services.
   ========================================================================== */

// Global Application State & Storage
const state = {
  activeView: 'home',
  currentRole: 'patient', // 'patient' or 'doctor'
  theme: 'slate', // 'slate', 'dark-emerald', 'high-contrast'
  fontSize: 'normal', // 'normal', 'large', 'xlarge'
  largeTargets: false,
  reduceMotion: false,
  
  // Patient Profile Mock Data
  patient: {
    name: 'Eleanor Vance',
    id: 'PV-88942',
    dob: 'August 14, 1968',
    joined: 'January 12, 2026',
    doctor: 'Dr. Robert Sterling, MD',
    contact: '+1 (555) 382-9912',
    emergency: 'Arthur Vance (Spouse) - +1 (555) 882-1049',
    speechCount: 24,
    writingCount: 18,
    motorCount: 7
  },

  // Today's Reminders Checklist
  reminders: [
    { id: 1, text: 'Morning Speech Practice Exercise', completed: true },
    { id: 2, text: 'Handwriting Digitization Task', completed: true },
    { id: 3, text: 'Evening Motor Assessment (Spiral)', completed: false, time: '7:00 PM' }
  ],

  // Activity History Database
  history: [
    {
      id: 'act-101',
      type: 'speech',
      title: 'Speech → Text Transcription',
      snippet: 'I would like to visit the doctor tomorrow morning.',
      date: 'Today, 10:42 AM',
      fullDate: 'Sep 25, 2026',
      status: 'Completed',
      metrics: '42 words • 12 sec audio',
      translation: 'मुझे कल सुबह डॉक्टर के पास जाना है।',
      targetLang: 'Hindi'
    },
    {
      id: 'act-102',
      type: 'writing',
      title: 'Handwriting → Text OCR',
      snippet: 'Take evening medicine at 8:00 PM precisely.',
      date: 'Today, 09:15 AM',
      fullDate: 'Sep 25, 2026',
      status: 'Completed',
      metrics: '28 words recognized • High clarity',
      translation: '8.00 PM ला संध्याकाळचे औषध घ्या.',
      targetLang: 'Marathi'
    },
    {
      id: 'act-103',
      type: 'motor',
      title: 'Spiral Motor Assessment',
      snippet: 'App-generated motor activity metric assessment completed.',
      date: 'Yesterday, 06:30 PM',
      fullDate: 'Sep 24, 2026',
      status: 'Completed',
      metrics: 'Consistency: 81% • Smoothness: 74% • Tremor: Mild',
      details: { tremor: 'Mild', smoothness: '74%', deviation: 'Low', consistency: '81%' }
    },
    {
      id: 'act-104',
      type: 'speech',
      title: 'Speech → Text Transcription',
      snippet: 'Please check if the physical therapy session is scheduled.',
      date: 'Sep 23, 2026',
      fullDate: 'Sep 23, 2026',
      status: 'Completed',
      metrics: '35 words • 10 sec audio'
    },
    {
      id: 'act-105',
      type: 'motor',
      title: 'Spiral Motor Assessment',
      snippet: 'Baseline motor assessment session.',
      date: 'Sep 21, 2026',
      fullDate: 'Sep 21, 2026',
      status: 'Completed',
      metrics: 'Consistency: 78% • Smoothness: 71% • Tremor: Mild',
      details: { tremor: 'Mild', smoothness: '71%', deviation: 'Low', consistency: '78%' }
    }
  ],

  // Doctor View Patient Roster
  patientsRoster: [
    { id: 'P-101', name: 'Eleanor Vance', age: 58, lastActive: 'Today, 10:42 AM', speechScore: '88%', motorScore: '81%', status: 'Stable' },
    { id: 'P-102', name: 'Arthur Pendelton', age: 64, lastActive: 'Yesterday', speechScore: '74%', motorScore: '68%', status: 'Requires Review' },
    { id: 'P-103', name: 'Clara Oswald', age: 52, lastActive: 'Today, 08:30 AM', speechScore: '92%', motorScore: '86%', status: 'Improving' },
    { id: 'P-104', name: 'Marcus Brody', age: 71, lastActive: '3 days ago', speechScore: '65%', motorScore: '61%', status: 'Assigned Practice' }
  ]
};

/* ==========================================================================
   INITIALIZATION & EVENT BINDINGS
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initThemeAndAccessibility();
  initSpeakRecorder();
  initWriteCanvas();
  initMotorSpiralCanvas();
  initHistoryAndFilters();
  initProgressCharts();
});

/* ==========================================================================
   1. GLOBAL NAVIGATION & VIEW SWITCHER
   ========================================================================== */
function initNavigation() {
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach((item) => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const targetView = item.getAttribute('data-view');
      if (targetView) switchView(targetView);
    });
  });

  const sidebarToggle = document.getElementById('sidebar-toggle');
  const mobileToggle = document.getElementById('mobile-menu-toggle');
  const sidebar = document.getElementById('sidebar');

  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
    });
  }

  if (mobileToggle) {
    mobileToggle.addEventListener('click', () => {
      sidebar.classList.toggle('mobile-open');
    });
  }
}

function switchView(viewName) {
  state.activeView = viewName;

  // Update Navigation Active State
  document.querySelectorAll('.nav-item').forEach((el) => {
    if (el.getAttribute('data-view') === viewName) {
      el.classList.add('active');
    } else {
      el.classList.remove('active');
    }
  });

  // Switch View Container
  document.querySelectorAll('.page-view').forEach((el) => {
    if (el.id === `view-${viewName}`) {
      el.classList.add('active');
    } else {
      el.classList.remove('active');
    }
  });

  // Close mobile sidebar if open
  document.getElementById('sidebar').classList.remove('mobile-open');

  // Trigger sub-view redraws
  if (viewName === 'progress') renderProgressCharts();
  if (viewName === 'motor') resetMotorSpiralCanvas();

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* ==========================================================================
   2. THEME & ACCESSIBILITY CONTROLLERS
   ========================================================================== */
function initThemeAndAccessibility() {
  const themeSelect = document.getElementById('theme-select');
  const fontSelect = document.getElementById('font-size-select');
  const contrastToggle = document.getElementById('quick-contrast-btn');
  const targetToggle = document.getElementById('quick-target-btn');

  if (themeSelect) {
    themeSelect.addEventListener('change', (e) => setTheme(e.target.value));
  }

  if (contrastToggle) {
    contrastToggle.addEventListener('click', () => {
      if (state.theme === 'high-contrast') {
        setTheme('slate');
      } else {
        setTheme('high-contrast');
      }
    });
  }

  if (targetToggle) {
    targetToggle.addEventListener('click', () => {
      state.largeTargets = !state.largeTargets;
      document.body.classList.toggle('large-targets', state.largeTargets);
      targetToggle.classList.toggle('active', state.largeTargets);
      showToast(state.largeTargets ? 'Large touch targets enabled' : 'Normal touch targets enabled');
    });
  }
}

function setTheme(themeName) {
  state.theme = themeName;
  document.body.classList.remove('theme-dark-emerald', 'theme-high-contrast');
  if (themeName === 'dark-emerald') document.body.classList.add('theme-dark-emerald');
  if (themeName === 'high-contrast') document.body.classList.add('theme-high-contrast');
  showToast(`Theme changed to ${themeName.replace('-', ' ')}`);
}

function setFontSize(size) {
  state.fontSize = size;
  document.body.classList.remove('font-large', 'font-xlarge');
  if (size === 'large') document.body.classList.add('font-large');
  if (size === 'xlarge') document.body.classList.add('font-xlarge');
}

/* ==========================================================================
   3. SPEAK MODULE (Record -> Speech to Text -> Edit/Translate/Save)
   ========================================================================== */
let recordingTimer = null;
let recordingSeconds = 0;
let isRecording = false;

function initSpeakRecorder() {
  const micBtn = document.getElementById('speak-mic-btn');
  const timerEl = document.getElementById('speak-timer');
  const outputBox = document.getElementById('speak-transcription-output');
  const textInput = document.getElementById('transcription-text');

  if (!micBtn) return;

  micBtn.addEventListener('click', () => {
    if (!isRecording) {
      // Start Recording
      isRecording = true;
      micBtn.classList.add('recording');
      document.querySelector('.speak-recorder-card').classList.add('recording');
      document.getElementById('speak-status-prompt').innerText = "Recording... Speak naturally now.";
      recordingSeconds = 0;

      recordingTimer = setInterval(() => {
        recordingSeconds++;
        const mins = String(Math.floor(recordingSeconds / 60)).padStart(2, '0');
        const secs = String(recordingSeconds % 60).padStart(2, '0');
        if (timerEl) timerEl.innerText = `${mins}:${secs}`;
      }, 1000);

    } else {
      // Stop Recording & Process Speech
      isRecording = false;
      micBtn.classList.remove('recording');
      document.querySelector('.speak-recorder-card').classList.remove('recording');
      clearInterval(recordingTimer);
      document.getElementById('speak-status-prompt').innerText = "Converting your speech into digital text...";

      setTimeout(() => {
        document.getElementById('speak-status-prompt').innerText = "Tap the microphone to start speaking.";
        if (outputBox) outputBox.style.display = 'block';

        const sampleTranscriptions = [
          "I would like to schedule my next physical therapy appointment for tomorrow afternoon.",
          "Please remind me to take my morning medication with a full glass of water.",
          "I am feeling much better today after completing the drawing exercises."
        ];
        const randomText = sampleTranscriptions[Math.floor(Math.random() * sampleTranscriptions.length)];
        if (textInput) textInput.value = randomText;
        showToast("Speech converted to text successfully!");
      }, 1200);
    }
  });
}

function handleTranslation() {
  const targetLang = document.getElementById('target-language-select').value;
  const sourceText = document.getElementById('transcription-text').value;
  const translatedBox = document.getElementById('translated-text-box');
  const panel = document.getElementById('translation-result-panel');

  if (!sourceText) {
    showToast("Please enter or record speech first");
    return;
  }

  const mockTranslations = {
    Hindi: 'मुझे कल दोपहर के लिए अपनी अगली फिजियोथेरेपी नियुक्ति का समय निर्धारित करना है।',
    Marathi: 'मला उद्या दुपारसाठी माझी पुढील फिजिओथेरपीची वेळ निश्चित करायची आहे.',
    Spanish: 'Me gustaría programar mi próxima cita de fisioterapia para mañana por la tarde.',
    French: 'Je souhaiterais programmer mon prochain rendez-vous de physiothérapie pour demain après-midi.',
    German: 'Ich möchte meinen nächsten Physiotherapie-Termin für morgen Nachmittag vereinbaren.'
  };

  if (panel) panel.style.display = 'block';
  if (translatedBox) translatedBox.innerText = mockTranslations[targetLang] || sourceText;
  showToast(`Translated text to ${targetLang}`);
}

function saveSpeechActivity() {
  const text = document.getElementById('transcription-text').value;
  if (!text) return;

  const newActivity = {
    id: `act-${Date.now()}`,
    type: 'speech',
    title: 'Speech → Text Transcription',
    snippet: text,
    date: 'Just now',
    fullDate: new Date().toLocaleDateString(),
    status: 'Completed',
    metrics: `${text.split(' ').length} words`
  };

  state.history.unshift(newActivity);
  state.patient.speechCount++;
  renderHistoryTable();
  showToast("Speech activity saved to history!");
}

/* ==========================================================================
   4. WRITE MODULE (Upload / Digital Handwriting Canvas)
   ========================================================================== */
let writeCanvas, writeCtx, isDrawingWrite = false;

function initWriteCanvas() {
  writeCanvas = document.getElementById('write-drawing-canvas');
  if (!writeCanvas) return;

  writeCtx = writeCanvas.getContext('2d');
  resizeCanvas(writeCanvas);

  writeCanvas.addEventListener('mousedown', startWriteDraw);
  writeCanvas.addEventListener('mousemove', drawWrite);
  writeCanvas.addEventListener('mouseup', stopWriteDraw);
  writeCanvas.addEventListener('mouseleave', stopWriteDraw);

  // Touch device support
  writeCanvas.addEventListener('touchstart', (e) => {
    e.preventDefault();
    const touch = e.touches[0];
    const rect = writeCanvas.getBoundingClientRect();
    isDrawingWrite = true;
    writeCtx.beginPath();
    writeCtx.moveTo(touch.clientX - rect.left, touch.clientY - rect.top);
  });

  writeCanvas.addEventListener('touchmove', (e) => {
    e.preventDefault();
    if (!isDrawingWrite) return;
    const touch = e.touches[0];
    const rect = writeCanvas.getBoundingClientRect();
    writeCtx.lineWidth = 4;
    writeCtx.lineCap = 'round';
    writeCtx.strokeStyle = '#3D261D';
    writeCtx.lineTo(touch.clientX - rect.left, touch.clientY - rect.top);
    writeCtx.stroke();
  });

  writeCanvas.addEventListener('touchend', stopWriteDraw);
}

function resizeCanvas(canvas) {
  if (!canvas || !canvas.parentElement) return;
  canvas.width = canvas.parentElement.clientWidth || 400;
  canvas.height = 280;
}

function startWriteDraw(e) {
  isDrawingWrite = true;
  const rect = writeCanvas.getBoundingClientRect();
  writeCtx.beginPath();
  writeCtx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
}

function drawWrite(e) {
  if (!isDrawingWrite) return;
  const rect = writeCanvas.getBoundingClientRect();
  writeCtx.lineWidth = 4;
  writeCtx.lineCap = 'round';
  writeCtx.strokeStyle = '#3D261D';
  writeCtx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
  writeCtx.stroke();
}

function stopWriteDraw() {
  isDrawingWrite = false;
}

function clearWriteCanvas() {
  if (writeCtx && writeCanvas) {
    writeCtx.clearRect(0, 0, writeCanvas.width, writeCanvas.height);
  }
}

function submitWriteHandwriting() {
  const resultCard = document.getElementById('write-ocr-result-card');
  const resultText = document.getElementById('write-recognized-text');

  showToast("Analyzing handwriting...");
  setTimeout(() => {
    if (resultCard) resultCard.style.display = 'block';
    if (resultText) resultText.value = "Take evening medication at 8:00 PM with water.";
    showToast("Handwriting recognized successfully!");
  }, 1000);
}

/* ==========================================================================
   5. MOTOR SPIRAL ASSESSMENT CANVAS & METRICS ENGINE
   ========================================================================== */
let motorCanvas, motorCtx, isDrawingMotor = false;

function initMotorSpiralCanvas() {
  motorCanvas = document.getElementById('motor-spiral-canvas');
  if (!motorCanvas) return;

  motorCtx = motorCanvas.getContext('2d');
  resetMotorSpiralCanvas();

  motorCanvas.addEventListener('mousedown', (e) => {
    isDrawingMotor = true;
    const rect = motorCanvas.getBoundingClientRect();
    motorCtx.beginPath();
    motorCtx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  });

  motorCanvas.addEventListener('mousemove', (e) => {
    if (!isDrawingMotor) return;
    const rect = motorCanvas.getBoundingClientRect();
    motorCtx.lineWidth = 3;
    motorCtx.lineCap = 'round';
    motorCtx.strokeStyle = '#3D261D';
    motorCtx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    motorCtx.stroke();
  });

  motorCanvas.addEventListener('mouseup', () => isDrawingMotor = false);
  motorCanvas.addEventListener('mouseleave', () => isDrawingMotor = false);
}

function resetMotorSpiralCanvas() {
  if (!motorCanvas || !motorCtx) return;

  motorCanvas.width = 440;
  motorCanvas.height = 440;
  motorCtx.clearRect(0, 0, 440, 440);

  // Draw Faint Guide Archimedean Spiral in Background
  motorCtx.save();
  motorCtx.strokeStyle = 'rgba(61, 38, 29, 0.2)';
  motorCtx.lineWidth = 2;
  motorCtx.setLineDash([6, 6]);

  const centerX = 220;
  const centerY = 220;
  motorCtx.beginPath();
  for (let i = 0; i < 720; i++) {
    const angle = 0.1 * i;
    const radius = 3 * angle;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    if (i === 0) motorCtx.moveTo(x, y);
    else motorCtx.lineTo(x, y);
  }
  motorCtx.stroke();
  motorCtx.restore();
}

function submitMotorAssessment() {
  const resultsCard = document.getElementById('motor-results-card');

  showToast("Analyzing your drawing metrics...");
  setTimeout(() => {
    if (resultsCard) resultsCard.style.display = 'block';

    // App-generated non-diagnostic metric calculations
    document.getElementById('metric-tremor').innerText = "Mild";
    document.getElementById('metric-smoothness').innerText = "76%";
    document.getElementById('metric-deviation').innerText = "Low";
    document.getElementById('metric-consistency').innerText = "83%";

    state.patient.motorCount++;
    showToast("Assessment complete! Results saved.");
  }, 1200);
}

/* ==========================================================================
   6. HISTORY & FILTERS ENGINE
   ========================================================================== */
function initHistoryAndFilters() {
  renderHistoryTable();

  const searchInput = document.getElementById('history-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', () => filterHistory());
  }

  const filterBtns = document.querySelectorAll('.history-filter-btn');
  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterBtns.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      filterHistory();
    });
  });
}

function renderHistoryTable(filteredItems = state.history) {
  const tbody = document.getElementById('history-table-body');
  if (!tbody) return;

  const getIconSvg = (type) => {
    if (type === 'speech') {
      return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/></svg>`;
    }
    if (type === 'writing') {
      return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>`;
    }
    return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 12a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/><path d="M12 6a7 7 0 1 0 7 7"/><path d="M12 2a11 11 0 1 0 11 11"/></svg>`;
  };

  tbody.innerHTML = filteredItems.map((item) => `
    <tr>
      <td>
        <div class="activity-type-cell">
          <div class="activity-type-icon icon-${item.type}">
            ${getIconSvg(item.type)}
          </div>
          <div>
            <strong>${item.title}</strong>
            <div style="font-size: 0.78rem; color: var(--text-muted);">${item.metrics}</div>
          </div>
        </div>
      </td>
      <td style="max-width: 320px;">
        <span style="color: var(--text-secondary);">${item.snippet}</span>
      </td>
      <td>
        <span class="status-badge">${item.status}</span>
      </td>
      <td style="font-family: var(--font-mono); font-size: 0.85rem; color: var(--text-muted);">
        ${item.date}
      </td>
      <td>
        <button class="btn-table-view" onclick="openActivityDetails('${item.id}')">View</button>
      </td>
    </tr>
  `).join('');
}

function filterHistory() {
  const searchVal = (document.getElementById('history-search-input')?.value || '').toLowerCase();
  const activeFilter = document.querySelector('.history-filter-btn.active')?.getAttribute('data-filter') || 'all';

  const filtered = state.history.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchVal) || item.snippet.toLowerCase().includes(searchVal);
    const matchesFilter = activeFilter === 'all' || item.type === activeFilter;
    return matchesSearch && matchesFilter;
  });

  renderHistoryTable(filtered);
}

function openActivityDetails(id) {
  const item = state.history.find((h) => h.id === id);
  if (!item) return;

  const modal = document.getElementById('activity-details-modal');
  const body = document.getElementById('modal-details-content');

  if (body) {
    body.innerHTML = `
      <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem;">${item.title}</h3>
      <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 1.5rem;">Recorded on ${item.fullDate}</p>

      <div style="background: var(--bg-surface-hover); padding: 1.25rem; border-radius: var(--radius-md); margin-bottom: 1.5rem;">
        <h5 style="margin-bottom: 0.5rem;">Activity Content / Result</h5>
        <p style="font-size: 1.05rem; color: var(--text-primary);">${item.snippet}</p>
        ${item.translation ? `<div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px dashed var(--border-light);">
          <strong>Translation (${item.targetLang}):</strong> ${item.translation}
        </div>` : ''}
      </div>

      <div style="display: flex; gap: 1rem;">
        <button class="btn-secondary" onclick="showToast('Activity downloaded'); closeModal();">Download PDF</button>
        <button class="btn-secondary" style="color: #ef4444;" onclick="deleteActivity('${item.id}')">Delete Entry</button>
      </div>
    `;
  }

  if (modal) modal.classList.add('active');
}

function closeModal() {
  document.querySelectorAll('.modal-overlay').forEach((m) => m.classList.remove('active'));
}

function deleteActivity(id) {
  state.history = state.history.filter((h) => h.id !== id);
  renderHistoryTable();
  closeModal();
  showToast("Activity entry deleted");
}

/* ==========================================================================
   7. PROGRESS CHARTS ENGINE
   ========================================================================== */
function initProgressCharts() {
  renderProgressCharts();
}

function renderProgressCharts() {
  const chartBox = document.getElementById('overall-progress-chart');
  if (!chartBox) return;

  // Render Accessible Interactive SVG Line & Bar Chart
  chartBox.innerHTML = `
    <svg viewBox="0 0 800 200" style="width: 100%; height: 100%; overflow: visible;">
      <!-- Gridlines -->
      <line x1="40" y1="40" x2="760" y2="40" stroke="var(--border-light)" stroke-dasharray="4 4" />
      <line x1="40" y1="90" x2="760" y2="90" stroke="var(--border-light)" stroke-dasharray="4 4" />
      <line x1="40" y1="140" x2="760" y2="140" stroke="var(--border-light)" stroke-dasharray="4 4" />

      <!-- Area Fill Under Curve -->
      <polygon points="60,140 160,110 260,130 360,70 460,95 560,50 660,65 740,45 740,160 60,160" fill="rgba(61, 38, 29, 0.08)" />

      <!-- Smooth Trend Line -->
      <polyline points="60,140 160,110 260,130 360,70 460,95 560,50 660,65 740,45" 
                fill="none" stroke="#3D261D" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />

      <!-- Interactive Data Points -->
      <circle cx="60" cy="140" r="6" fill="#3D261D" />
      <circle cx="160" cy="110" r="6" fill="#3D261D" />
      <circle cx="260" cy="130" r="6" fill="#3D261D" />
      <circle cx="360" cy="70" r="6" fill="#3D261D" />
      <circle cx="460" cy="95" r="6" fill="#3D261D" />
      <circle cx="560" cy="50" r="6" fill="#3D261D" />
      <circle cx="660" cy="65" r="6" fill="#3D261D" />
      <circle cx="740" cy="45" r="6" fill="#3D261D" />

      <!-- Day Labels -->
      <text x="60" y="185" fill="var(--text-muted)" font-size="12" text-anchor="middle">Mon</text>
      <text x="160" y="185" fill="var(--text-muted)" font-size="12" text-anchor="middle">Tue</text>
      <text x="260" y="185" fill="var(--text-muted)" font-size="12" text-anchor="middle">Wed</text>
      <text x="360" y="185" fill="var(--text-muted)" font-size="12" text-anchor="middle">Thu</text>
      <text x="460" y="185" fill="var(--text-muted)" font-size="12" text-anchor="middle">Fri</text>
      <text x="560" y="185" fill="var(--text-muted)" font-size="12" text-anchor="middle">Sat</text>
      <text x="660" y="185" fill="var(--text-muted)" font-size="12" text-anchor="middle">Sun</text>
      <text x="740" y="185" fill="var(--text-muted)" font-size="12" text-anchor="middle">Today</text>
    </svg>
  `;
}

/* ==========================================================================
   8. DOCTOR / CAREGIVER DASHBOARD
   ========================================================================== */
function initDoctorDashboard() {
  const container = document.getElementById('doctor-patients-container');
  if (!container) return;

  container.innerHTML = state.patientsRoster.map((patient) => `
    <div class="patient-doctor-card">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
        <div>
          <h4 style="font-size: 1.25rem; font-weight: 700;">${patient.name}</h4>
          <span style="font-size: 0.8rem; color: var(--text-muted); font-family: var(--font-mono);">${patient.id} • Age ${patient.age}</span>
        </div>
        <span class="status-badge">${patient.status}</span>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 1.25rem;">
        <div style="background: var(--bg-surface-hover); padding: 0.65rem; border-radius: var(--radius-sm);">
          <div style="font-size: 0.75rem; color: var(--text-muted);">Speech Score</div>
          <strong style="color: var(--accent-teal); font-size: 1.1rem;">${patient.speechScore}</strong>
        </div>
        <div style="background: var(--bg-surface-hover); padding: 0.65rem; border-radius: var(--radius-sm);">
          <div style="font-size: 0.75rem; color: var(--text-muted);">Motor Score</div>
          <strong style="color: var(--accent-emerald); font-size: 1.1rem;">${patient.motorScore}</strong>
        </div>
      </div>

      <button class="btn-secondary" style="width: 100%; justify-content: center;" onclick="showToast('Opened details for ${patient.name}')">
        Inspect Patient File &rarr;
      </button>
    </div>
  `).join('');
}

function toggleUserRole() {
  state.currentRole = state.currentRole === 'patient' ? 'doctor' : 'patient';
  const roleText = document.getElementById('current-role-text');
  if (roleText) roleText.innerText = state.currentRole === 'patient' ? 'Patient View' : 'Doctor / Caregiver View';
  
  if (state.currentRole === 'doctor') {
    switchView('doctor');
    showToast("Switched to Doctor / Caregiver Mode");
  } else {
    switchView('home');
    showToast("Switched to Patient View");
  }
}

/* ==========================================================================
   9. HOME REMINDERS & TOAST DISPENSER
   ========================================================================== */
function renderHomeReminders() {
  const container = document.getElementById('home-reminders-list');
  if (!container) return;

  container.innerHTML = state.reminders.map((r) => `
    <div class="reminder-checkbox-item ${r.completed ? 'completed' : ''}" onclick="toggleReminder(${r.id})">
      <div class="custom-checkbox">${r.completed ? '✓' : ''}</div>
      <span class="task-label">${r.text} ${r.time ? `<strong style="font-size: 0.75rem; color: var(--accent-amber);">(${r.time})</strong>` : ''}</span>
    </div>
  `).join('');
}

function toggleReminder(id) {
  const item = state.reminders.find((r) => r.id === id);
  if (item) {
    item.completed = !item.completed;
    renderHomeReminders();
    showToast(item.completed ? "Task marked as completed!" : "Task marked as pending");
  }
}

function generateReportPDF() {
  showToast("Generating PDF Progress Report...");
  setTimeout(() => {
    window.print();
  }, 800);
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text);
  showToast("Text copied to clipboard!");
}

function showToast(message) {
  let toastBox = document.getElementById('toast-container');
  if (!toastBox) {
    toastBox = document.createElement('div');
    toastBox.id = 'toast-container';
    toastBox.className = 'toast-container';
    document.body.appendChild(toastBox);
  }

  const toast = document.createElement('div');
  toast.className = 'toast-message';
  toast.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6E56CF" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg> <span>${message}</span>`;
  toastBox.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3200);
}
